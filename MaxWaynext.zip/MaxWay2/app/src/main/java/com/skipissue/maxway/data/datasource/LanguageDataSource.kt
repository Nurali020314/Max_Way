package com.skipissue.maxway.data.datasource

interface LanguageDataSource {
    fun setLanguage(value:Int)

    fun getLanguage():Int
}