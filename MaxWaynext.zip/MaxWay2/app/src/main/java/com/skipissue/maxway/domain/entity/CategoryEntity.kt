package com.skipissue.maxway.domain.entity

class CategoryEntity (
    val id: Int,
    val name: String,
    val data: List<FoodEntity>
)