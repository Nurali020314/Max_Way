package com.skipissue.maxway.domain.entity

class FoodEntity (
    val id: Int,
    val name: String,
    val cost: String
)