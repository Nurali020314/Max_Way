package com.skipissue.maxway.domain.entity

class TabEntity(
    val id: String,
    val title: String
)