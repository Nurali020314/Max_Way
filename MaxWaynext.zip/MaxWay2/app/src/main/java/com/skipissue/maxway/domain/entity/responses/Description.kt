package com.skipissue.maxway.domain.entity.responses

data class Description(
    val en: String,
    val ru: String,
    val uz: String
)