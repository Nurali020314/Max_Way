package com.skipissue.maxway.domain.entity.responses

data class Rate(
    val code: String,
    val id: String,
    val rate_amount: String,
    val slug: String,
    val title: String
)