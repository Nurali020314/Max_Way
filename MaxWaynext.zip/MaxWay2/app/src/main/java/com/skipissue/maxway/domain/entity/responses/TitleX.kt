package com.skipissue.maxway.domain.entity.responses

data class TitleX(
    val en: String,
    val ru: String,
    val uz: String
)