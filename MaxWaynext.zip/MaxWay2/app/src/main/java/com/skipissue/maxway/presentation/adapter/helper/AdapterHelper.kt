package com.skipissue.maxway.presentation.adapter.helper

interface AdapterHelper {
    fun innerPosition(id:Int):Int
}