package com.skipissue.maxway.presentation.adapter.helper

class AdapterHelperImpl : AdapterHelper {
    override fun innerPosition(id: Int): Int {
        return id
    }
}