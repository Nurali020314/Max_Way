package com.skipissue.maxway.presentation.screens.basket

import androidx.fragment.app.Fragment
import com.skipissue.maxway.R

class BasketFragment:Fragment(R.layout.fragment_basket) {
}