package com.skipissue.maxway.presentation.screens.order

import androidx.fragment.app.Fragment
import com.skipissue.maxway.R

class OrderFragment:Fragment(R.layout.fragment_order) {
}