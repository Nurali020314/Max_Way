package com.skipissue.maxway.presentation.screens.profil

import androidx.fragment.app.Fragment
import com.skipissue.maxway.R

class ProfileFragment:Fragment(R.layout.fragment_profile) {

}